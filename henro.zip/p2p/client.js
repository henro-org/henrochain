const fs = require('fs');
const path = require('path');
const io = require('socket.io-client');