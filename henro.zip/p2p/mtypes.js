const MESSAGE_TYPES = {
    id: 'ID',
    chain: 'CHAIN',
    transaction: 'TRANSACTION',
    clearTransactions: 'CLEAR_TRANSACTIONS'
};

module.exports = MESSAGE_TYPES;